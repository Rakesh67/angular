import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-truck',
  templateUrl: './add-truck.component.html',
  styleUrls: ['./add-truck.component.css']
})
export class AddTruckComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
