import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-truck',
  templateUrl: './list-truck.component.html',
  styleUrls: ['./list-truck.component.css']
})
export class ListTruckComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
